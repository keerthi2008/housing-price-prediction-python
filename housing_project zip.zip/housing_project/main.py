import pandas as pd
#load dataset
data = pd.read_excel("housing_price_dataset.xlsx")
# this will print the first 5 rows so you can see it's working.
print (data.head())
print(data.info())
# check for column names.
print(data.columns)
# check for missing values.
print(data.isnull().sum())
# separate features & target.
X = data.drop("Price",axis=1)
Y=data["Price"]
# verify data.
print(X.head())
print(Y.head())
# check data shape.
print (X.shape)
print(Y.shape)
from sklearn.preprocessing import StandardScaler

scaler=StandardScaler()
X=scaler.fit_transform(X)
from sklearn.model_selection import train_test_split
# split the data.
X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.2,random_state=42)
# check split sizes.
print(X_train.shape)
print(X_test.shape)
print(Y_train.shape)
print(Y_test.shape)
# import model.
from sklearn.linear_model import LinearRegression
# create model.
model=LinearRegression()
# train the model 
model.fit(X_train,Y_train)
# check model  learned.
print("coefficiants",model.coef_)
print("intercept",model.intercept_)
# predict on test data.
prediction=model.predict(X_test)
# view predictions.
print(prediction[:5])
# compare actual vs predicted.
import pandas as pd 
results=pd.DataFrame({"actual price":Y_test.values,"predicted values":prediction})
print(results.head())
# predict custom input.
sample=[[2000,3,2,2,8,5]]
predicted_Price=model.predict(sample)
print("predicted house price:",predicted_Price)
# import metrices.
from sklearn.metrics import mean_absolute_error,r2_score
# calculate accuracy.
mae=mean_absolute_error(Y_test,prediction)
r2=r2_score(Y_test,prediction)

print("mean absolute error:",mae)
print("R2 score:",r2)
# visualization 
import matplotlib.pyplot as plt
plt.scatter(Y_test,prediction)
plt.xlabel("actual price")
plt.ylabel("predicted price")
plt.title("actual vs predicted_prices")
plt.plot([Y_test.min(),Y_test.max()],[Y_test.min(),Y_test.max()],color='red',lw=2)
# add a diagonal line for reference
plt.plot([Y_test.min(),Y_test.max()],[Y_test.min(),Y_test.max()],'r--') 
plt.show()

